
public class exceptionBrand extends Exception{
    public exceptionBrand(String message){
        super(message);
    }
}