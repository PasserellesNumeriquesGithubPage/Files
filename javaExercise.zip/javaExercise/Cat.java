public class Cat implements AnimalInterface{
    public void catColor(){
        System.out.println("Green");
    }
    public void catWeight(){
        System.out.println("30 kg");
    }
}