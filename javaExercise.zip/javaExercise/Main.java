// 1st. Create ang main
// 2nd. Create 2 classes. 1 for generic class. 2 Specific Class. Also create constructors.
// 3rd Create interface. at least 2 functions
public class Main {
    public static void main(String[] args) {
      Animal myAnimal = new Animal();
      myAnimal.setName("Tiger"); // Set the value of the name variable to "John"
      System.out.println(myAnimal.getName());
    //   System.out.println(var1.animalSound());
      }
  }