public interface AnimalInterface{
    public void catColor();
    public void catWeight();
}