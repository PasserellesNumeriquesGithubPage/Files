public class Cockroach extends Animal{
    public Cockroach(){
        super.animalSound(); // Call the superclass method
        System.out.println("The dog says: bow wow");
    }
}